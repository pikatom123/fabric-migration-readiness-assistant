"""Packaged assessment knowledge."""
